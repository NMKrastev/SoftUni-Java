package guild;

public final class Rank {

    public static final String MEMBER = "Member";
    public static final String TRIAL = "Trial";

    private Rank() {

    }
}
