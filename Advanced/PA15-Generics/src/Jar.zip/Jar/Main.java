package Jar;

public class Main {

    public static void main(String[] args) {

        Jar<String> stringJar = new Jar<String>();

        stringJar.add("Ivan");
        stringJar.add("Peter");

        System.out.println(stringJar.remove());

    }
}
