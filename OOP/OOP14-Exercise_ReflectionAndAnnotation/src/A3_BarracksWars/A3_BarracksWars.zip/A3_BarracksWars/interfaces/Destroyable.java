package A3_BarracksWars.interfaces;

public interface Destroyable {
    
    int getHealth();
    
    void setHealth(int health);
}
