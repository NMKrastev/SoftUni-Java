package A3_BarracksWars.interfaces;

public interface Runnable {
	void run();
}
