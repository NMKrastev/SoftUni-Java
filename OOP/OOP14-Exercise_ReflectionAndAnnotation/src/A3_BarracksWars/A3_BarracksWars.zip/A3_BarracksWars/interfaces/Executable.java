package A3_BarracksWars.interfaces;

public interface Executable {

	String execute();

}
