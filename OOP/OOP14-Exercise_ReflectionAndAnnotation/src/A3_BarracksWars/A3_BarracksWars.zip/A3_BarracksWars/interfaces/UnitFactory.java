package A3_BarracksWars.interfaces;

public interface UnitFactory {

    Unit createUnit(String unitType);
}