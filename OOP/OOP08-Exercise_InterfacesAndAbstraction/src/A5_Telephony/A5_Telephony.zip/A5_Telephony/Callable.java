package A5_Telephony;

public interface Callable {

    String call();
}
