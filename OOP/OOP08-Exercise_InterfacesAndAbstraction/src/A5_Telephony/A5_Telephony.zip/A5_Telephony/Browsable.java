package A5_Telephony;

public interface Browsable {

    String browse();
}
