package A3_BirthdayCelebrations;

public interface Identifiable {

    String getId();
}
