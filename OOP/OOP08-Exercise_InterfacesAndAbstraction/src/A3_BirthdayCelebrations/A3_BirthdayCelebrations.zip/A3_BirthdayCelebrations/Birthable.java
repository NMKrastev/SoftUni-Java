package A3_BirthdayCelebrations;

public interface Birthable {

    String getBirthDate();
}
