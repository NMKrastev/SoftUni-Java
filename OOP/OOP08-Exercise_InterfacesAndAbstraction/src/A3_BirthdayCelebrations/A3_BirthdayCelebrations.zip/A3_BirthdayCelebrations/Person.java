package A3_BirthdayCelebrations;

public interface Person {

    String getName();

    int getAge();
}
