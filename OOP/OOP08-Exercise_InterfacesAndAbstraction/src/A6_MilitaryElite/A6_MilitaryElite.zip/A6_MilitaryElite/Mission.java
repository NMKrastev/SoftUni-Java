package A6_MilitaryElite;

public interface Mission {

    String getMissionCodeName();

    State getState();
}
