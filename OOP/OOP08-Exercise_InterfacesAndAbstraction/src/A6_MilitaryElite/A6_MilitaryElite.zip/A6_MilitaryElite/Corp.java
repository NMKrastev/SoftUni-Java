package A6_MilitaryElite;

public enum Corp {

    Airforces,
    Marines
}
