package A6_MilitaryElite;

public enum State {

    inProgress,
    finished
}
