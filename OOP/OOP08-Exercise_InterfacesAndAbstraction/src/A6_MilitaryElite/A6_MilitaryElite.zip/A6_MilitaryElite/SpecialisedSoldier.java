package A6_MilitaryElite;

public interface SpecialisedSoldier extends Private {

    Corp getCrop();
}
