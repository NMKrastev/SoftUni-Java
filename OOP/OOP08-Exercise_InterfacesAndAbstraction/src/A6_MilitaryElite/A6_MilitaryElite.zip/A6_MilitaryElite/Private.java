package A6_MilitaryElite;

public interface Private extends Soldier {

    double getSalary();
}
