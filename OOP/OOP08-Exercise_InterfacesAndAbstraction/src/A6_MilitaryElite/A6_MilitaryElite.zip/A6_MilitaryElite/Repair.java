package A6_MilitaryElite;

public interface Repair {

    String getPartName();

    int getHoursWorked();
}
