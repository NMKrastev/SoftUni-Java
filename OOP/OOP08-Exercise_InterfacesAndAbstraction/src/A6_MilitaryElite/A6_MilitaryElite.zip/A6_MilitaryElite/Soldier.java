package A6_MilitaryElite;

public interface Soldier {

    int getId();

    String getFirstName();

    String getLastName();
}
