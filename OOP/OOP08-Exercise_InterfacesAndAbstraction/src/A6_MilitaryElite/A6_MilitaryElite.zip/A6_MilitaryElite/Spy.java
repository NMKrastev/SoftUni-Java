package A6_MilitaryElite;

public interface Spy {

    String getCodeNumber();
}
