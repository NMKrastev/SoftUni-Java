package A7_CollectionHierarchy;

public interface AddRemovable extends Addable {

    String remove();
}
