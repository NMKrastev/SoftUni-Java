package A7_CollectionHierarchy;

public interface Addable {

    int add(String item);
}
