package A7_CollectionHierarchy;

public interface MyList extends AddRemovable {

    int getUsed();
}
