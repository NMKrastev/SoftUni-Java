package A2_MultipleImplementation;

public interface Birthable {

    String getBirthDate();
}
