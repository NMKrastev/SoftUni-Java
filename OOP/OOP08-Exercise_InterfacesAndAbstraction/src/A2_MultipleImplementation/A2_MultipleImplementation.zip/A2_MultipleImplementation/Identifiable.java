package A2_MultipleImplementation;

public interface Identifiable {

    String getId();
}
