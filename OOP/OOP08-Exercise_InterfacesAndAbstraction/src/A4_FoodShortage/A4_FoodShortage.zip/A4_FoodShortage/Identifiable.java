package A4_FoodShortage;

public interface Identifiable {

    String getId();
}
