package A1_DefineAnInterfacePerson;

public interface Person {

    String getName();

    int getAge();
}
