package A1_Vehicles;

public interface Vehicle {

    void drive(double distance);

    void refuel(double fuel);
}
