package A3_Word;

public interface CommandInterface {

    void init();

    void handleInput(String input);
}
