package A2_VehiclesExtension;

public interface Vehicle {

    void drive(double distance);

    void refuel(double fuel);
}
