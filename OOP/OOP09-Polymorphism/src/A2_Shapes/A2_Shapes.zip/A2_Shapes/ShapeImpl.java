package A2_Shapes;

public abstract class ShapeImpl implements Shape {

    private Double perimeter;
    private Double area;

    @Override
    public Double getPerimeter() {
        return perimeter;
    }

    protected void setPerimeter(Double perimeter) {
        this.perimeter = perimeter;
    }

    @Override
    public Double getArea() {
        return area;
    }

    protected void setArea(Double area) {
        this.area = area;
    }
}
