package A4_TrafficLights;

public enum Color {

    RED,
    GREEN,
    YELLOW;
}
