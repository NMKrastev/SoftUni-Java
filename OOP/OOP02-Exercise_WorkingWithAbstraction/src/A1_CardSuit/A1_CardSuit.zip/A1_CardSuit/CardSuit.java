package A1_CardSuit;

public enum CardSuit {

    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES
}
