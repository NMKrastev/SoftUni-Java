package A6_GreedyTimes;

public enum ItemType {

    GOLD,
    GEM,
    CASH
}
