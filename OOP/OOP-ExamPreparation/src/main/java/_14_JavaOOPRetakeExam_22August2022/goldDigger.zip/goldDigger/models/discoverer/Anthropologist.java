package _14_JavaOOPRetakeExam_22August2022.goldDigger.models.discoverer;

public class Anthropologist extends BaseDiscoverer {

    private static final double ENERGY = 40;

    public Anthropologist(String name) {
        super(name, ENERGY);
    }
}
