package _14_JavaOOPRetakeExam_22August2022.goldDigger.models.museum;

import java.util.Collection;

public interface Museum {
    Collection<String> getExhibits();
}
