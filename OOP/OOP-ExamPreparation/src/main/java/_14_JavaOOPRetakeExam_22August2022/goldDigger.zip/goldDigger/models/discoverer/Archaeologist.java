package _14_JavaOOPRetakeExam_22August2022.goldDigger.models.discoverer;

public class Archaeologist extends BaseDiscoverer {

    private static final double ENERGY = 60;

    public Archaeologist(String name) {
        super(name, ENERGY);
    }
}
