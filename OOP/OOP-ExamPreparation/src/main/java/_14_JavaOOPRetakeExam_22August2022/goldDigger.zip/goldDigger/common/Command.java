package _14_JavaOOPRetakeExam_22August2022.goldDigger.common;

public enum Command {
    AddDiscoverer,
    AddSpot,
    ExcludeDiscoverer,
    InspectSpot,
    GetStatistics,
    Exit,
}
