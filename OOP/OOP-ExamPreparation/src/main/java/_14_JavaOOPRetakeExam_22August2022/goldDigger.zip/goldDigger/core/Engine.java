package _14_JavaOOPRetakeExam_22August2022.goldDigger.core;

public interface Engine extends Runnable{

}
