package _14_JavaOOPRetakeExam_22August2022.goldDigger.models.spot;

import java.util.Collection;

public interface Spot {

    Collection<String> getExhibits();

    String getName();
}
