package JavaOOPRetakeExam_18April2021.spaceStation.models.bags;

import java.util.Collection;

public interface Bag {
    Collection<String> getItems();
}
