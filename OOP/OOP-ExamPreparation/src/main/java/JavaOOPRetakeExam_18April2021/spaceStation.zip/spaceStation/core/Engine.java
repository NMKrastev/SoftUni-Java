package JavaOOPRetakeExam_18April2021.spaceStation.core;

public interface Engine extends Runnable {
}
