package JavaOOPRetakeExam_18April2021.spaceStation.common;

public enum Command {
    AddAstronaut,
    AddPlanet,
    RetireAstronaut,
    ExplorePlanet,
    Report,
    Exit,
}
