package JavaOOPRetakeExam_18April2021.spaceStation.models.planets;

import java.util.Collection;

public interface Planet {
    Collection<String> getItems();

    String getName();
}
