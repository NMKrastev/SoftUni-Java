package JavaOOPRetakeExam_19December2020.viceCity.core.interfaces;

public interface Engine extends Runnable {
}
