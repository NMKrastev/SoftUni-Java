package JavaOOPRetakeExam_19December2020.viceCity.common;

public enum  Command {
    AddPlayer,
    AddGun,
    AddGunToPlayer,
    Fight,
    Exit,
}
