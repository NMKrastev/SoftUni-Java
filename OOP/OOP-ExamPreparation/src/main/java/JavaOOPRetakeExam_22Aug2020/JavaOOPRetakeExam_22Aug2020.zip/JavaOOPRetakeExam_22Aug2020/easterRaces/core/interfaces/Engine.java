package JavaOOPRetakeExam_22Aug2020.easterRaces.core.interfaces;

public interface Engine extends Runnable {
}
