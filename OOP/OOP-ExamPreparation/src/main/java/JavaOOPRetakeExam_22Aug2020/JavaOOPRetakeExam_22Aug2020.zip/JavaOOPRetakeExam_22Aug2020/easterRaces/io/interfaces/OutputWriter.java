package JavaOOPRetakeExam_22Aug2020.easterRaces.io.interfaces;

public interface OutputWriter {
    void writeLine(String text);
}
