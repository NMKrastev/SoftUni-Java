package _01_JavaOOPExam_16August2020.onlineShop.core.interfaces;

public interface Engine extends Runnable {
}
