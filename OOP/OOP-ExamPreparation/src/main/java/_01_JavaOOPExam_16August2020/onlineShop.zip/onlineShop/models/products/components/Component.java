package _01_JavaOOPExam_16August2020.onlineShop.models.products.components;

import _01_JavaOOPExam_16August2020.onlineShop.models.products.Product;

public interface Component extends Product {

    int getGeneration();
}
