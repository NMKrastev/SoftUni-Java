package _07_JavaOOPExam_15August2021.restaurant.core.interfaces;

public interface Engine {
    void run();
}
