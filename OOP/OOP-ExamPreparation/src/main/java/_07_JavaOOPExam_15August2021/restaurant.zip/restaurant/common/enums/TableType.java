package _07_JavaOOPExam_15August2021.restaurant.common.enums;

public enum TableType {
    Indoors,
    InGarden
}
