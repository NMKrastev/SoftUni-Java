package _07_JavaOOPExam_15August2021.restaurant.entities.healthyFoods.interfaces;

public interface HealthyFood {
    String getName();

    double getPortion();

    double getPrice();
}
