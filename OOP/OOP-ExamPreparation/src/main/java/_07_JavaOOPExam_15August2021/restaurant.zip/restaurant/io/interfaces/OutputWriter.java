package _07_JavaOOPExam_15August2021.restaurant.io.interfaces;

public interface OutputWriter {
    void writeLine(String text);
}
