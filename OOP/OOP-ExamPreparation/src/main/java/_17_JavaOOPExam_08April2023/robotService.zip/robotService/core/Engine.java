package _17_JavaOOPExam_08April2023.robotService.core;

public interface Engine extends Runnable {
}

