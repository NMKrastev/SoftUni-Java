package _17_JavaOOPExam_08April2023.robotService.entities.supplements;

public interface Supplement {
    int getHardness();
    double getPrice();
}
