package _17_JavaOOPExam_08April2023.robotService.entities.services;

public class MainService extends BaseService {

    private static final int capacity = 30;

    public MainService(String name) {
        super(name, capacity);
    }
}
