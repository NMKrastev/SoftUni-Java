package _17_JavaOOPExam_08April2023.robotService.entities.robot;

public interface Robot {
    String getName();

    void setName(String name);

    int getKilograms();

    double getPrice();

    void eating();
}
