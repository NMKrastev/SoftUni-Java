package _17_JavaOOPExam_08April2023.robotService.entities.supplements;

public class PlasticArmor extends BaseSupplement {

    private static final int hardness = 1;
    private static final double price = 10;

    public PlasticArmor() {
        super(hardness, price);
    }
}
