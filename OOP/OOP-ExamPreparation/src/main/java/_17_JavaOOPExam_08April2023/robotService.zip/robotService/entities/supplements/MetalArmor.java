package _17_JavaOOPExam_08April2023.robotService.entities.supplements;

public class MetalArmor extends BaseSupplement {

    private static final int hardness = 5;
    private static final double price = 15;

    public MetalArmor() {
        super(hardness, price);
    }
}
