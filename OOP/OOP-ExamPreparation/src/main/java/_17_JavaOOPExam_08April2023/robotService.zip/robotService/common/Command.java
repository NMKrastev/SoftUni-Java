package _17_JavaOOPExam_08April2023.robotService.common;

public enum Command {
    AddService,
    AddSupplement,
    SupplementForService,
    AddRobot,
    FeedingRobot,
    SumOfAll,
    Statistics,
    End
}
