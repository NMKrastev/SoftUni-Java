package _10_JavaOOPRetakeExam20December2021.christmasRaces.common;

public enum Command {
    CreateDriver,
    CreateCar,
    AddCarToDriver,
    AddDriverToRace,
    CreateRace,
    StartRace,
    End
}
