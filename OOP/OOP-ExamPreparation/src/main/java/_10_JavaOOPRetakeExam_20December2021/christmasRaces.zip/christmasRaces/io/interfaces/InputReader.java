package _10_JavaOOPRetakeExam20December2021.christmasRaces.io.interfaces;

import java.io.IOException;

public interface InputReader {
    String readLine() throws IOException;
}
