package _12_JavaOOPRetakeExam_18April2022.zoo.entities.foods;

public interface Food {
    int getCalories();

    double getPrice();
}
