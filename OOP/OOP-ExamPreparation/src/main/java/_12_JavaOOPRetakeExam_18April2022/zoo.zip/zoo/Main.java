package _12_JavaOOPRetakeExam_18April2022.zoo;

import _12_JavaOOPRetakeExam_18April2022.zoo.core.Engine;
import _12_JavaOOPRetakeExam_18April2022.zoo.core.EngineImpl;

public class Main {

    public static void main(String[] args) {
        Engine engine = new EngineImpl();
        engine.run();
    }
}
