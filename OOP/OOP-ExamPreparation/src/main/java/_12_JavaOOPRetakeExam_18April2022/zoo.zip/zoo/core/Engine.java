package _12_JavaOOPRetakeExam_18April2022.zoo.core;

public interface Engine extends Runnable {
}
