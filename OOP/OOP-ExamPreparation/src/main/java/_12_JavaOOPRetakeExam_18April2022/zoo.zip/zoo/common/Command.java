package _12_JavaOOPRetakeExam_18April2022.zoo.common;
public enum Command {
    AddArea,
    BuyFood,
    FoodForArea,
    AddAnimal,
    FeedAnimal,
    CalculateKg,
    GetStatistics,
    Exit
}

