package _03_JavaOOPExam_12December2020.bakery.entities.bakedFoods.interfaces;

public interface BakedFood {
    String getName();

    double getPortion();

    double getPrice();
}
