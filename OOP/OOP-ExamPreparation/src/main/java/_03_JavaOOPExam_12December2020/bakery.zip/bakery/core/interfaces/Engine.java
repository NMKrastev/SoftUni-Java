package _03_JavaOOPExam_12December2020.bakery.core.interfaces;

public interface Engine {
    void run();
}
