package _03_JavaOOPExam_12December2020.bakery.common.enums;

public enum DrinkType {
    Tea,
    Water
}
