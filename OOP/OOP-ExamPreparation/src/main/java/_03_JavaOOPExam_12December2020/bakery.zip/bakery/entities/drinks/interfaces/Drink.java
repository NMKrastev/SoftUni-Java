package _03_JavaOOPExam_12December2020.bakery.entities.drinks.interfaces;

public interface Drink {
    String getName();

    int getPortion();

    double getPrice();

    String getBrand();
}
