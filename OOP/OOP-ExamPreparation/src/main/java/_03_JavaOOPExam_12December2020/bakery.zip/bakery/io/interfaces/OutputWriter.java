package _03_JavaOOPExam_12December2020.bakery.io.interfaces;

public interface OutputWriter {
    void writeLine(String text);
}
