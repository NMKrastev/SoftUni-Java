package _03_JavaOOPExam_12December2020.bakery.io.interfaces;

import java.io.IOException;

public interface InputReader {
    String readLine() throws IOException;
}
