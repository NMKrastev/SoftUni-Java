package bakery.common.enums;

public enum BakedFoodType {
    Bread,
    Cake
}
