package JavaOOPExam_10April2021.aquarium.entities.fish;

public interface Fish {
    void setName(String name);

    void eat();

    int getSize();

    String getName();

    double getPrice();
}
