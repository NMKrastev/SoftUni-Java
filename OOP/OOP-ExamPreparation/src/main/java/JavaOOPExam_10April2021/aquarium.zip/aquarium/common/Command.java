package JavaOOPExam_10April2021.aquarium.common;

public enum Command {
    AddAquarium,
    AddDecoration,
    InsertDecoration,
    AddFish,
    FeedFish,
    CalculateValue,
    Report,
    Exit
}
