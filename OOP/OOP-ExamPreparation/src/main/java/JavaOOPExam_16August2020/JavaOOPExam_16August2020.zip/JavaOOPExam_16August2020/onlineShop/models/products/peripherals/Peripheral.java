package JavaOOPExam_16August2020.onlineShop.models.products.peripherals;

import JavaOOPExam_16August2020.onlineShop.models.products.Product;

public interface Peripheral extends Product {
    String getConnectionType();
}
