package JavaOOPExam_16August2020.onlineShop.io.interfaces;

public interface OutputWriter {
    void writeLine(String text);
}
