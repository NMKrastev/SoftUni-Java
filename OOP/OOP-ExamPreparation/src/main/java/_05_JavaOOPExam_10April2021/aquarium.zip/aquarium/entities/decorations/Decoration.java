package _05_JavaOOPExam_10April2021.aquarium.entities.decorations;

public interface Decoration {
    int getComfort();

    double getPrice();
}
