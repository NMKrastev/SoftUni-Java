package _05_JavaOOPExam_10April2021.aquarium.core;

public interface Engine extends Runnable {
}

