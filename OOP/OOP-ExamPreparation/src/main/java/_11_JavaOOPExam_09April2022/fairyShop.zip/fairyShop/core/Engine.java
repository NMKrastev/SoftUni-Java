package _11_JavaOOPExam09April2022.fairyShop.core;

public interface Engine extends Runnable {
    void run();
}
