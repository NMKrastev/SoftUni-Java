package _11_JavaOOPExam09April2022.fairyShop.models;

public interface Instrument {
    int getPower();

    void use();

    boolean isBroken();
}
