package _11_JavaOOPExam09April2022.fairyShop.common;

public enum Command {
    AddHelper,
    AddPresent,
    AddInstrumentToHelper,
    CraftPresent,
    Report,
    Exit,
}
