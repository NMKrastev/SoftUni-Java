package _11_JavaOOPExam09April2022.fairyShop.models;

public interface Shop {
    void craft(Present present, Helper helper);
}
