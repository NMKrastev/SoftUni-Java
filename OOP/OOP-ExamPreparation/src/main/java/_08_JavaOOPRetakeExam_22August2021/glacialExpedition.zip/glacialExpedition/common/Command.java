package _08_JavaOOPRetakeExam_22August2021.glacialExpedition.common;

public enum Command {
    AddExplorer,
    AddState,
    RetireExplorer,
    ExploreState,
    FinalResult,
    Exit,
}
