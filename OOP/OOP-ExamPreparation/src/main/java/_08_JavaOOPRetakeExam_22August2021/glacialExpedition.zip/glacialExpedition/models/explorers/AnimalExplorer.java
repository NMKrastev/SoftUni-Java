package _08_JavaOOPRetakeExam_22August2021.glacialExpedition.models.explorers;

public class AnimalExplorer extends BaseExplorer {

    private static final double ENERGY = 100;

    public AnimalExplorer(String name) {
        super(name, ENERGY);
    }
}
