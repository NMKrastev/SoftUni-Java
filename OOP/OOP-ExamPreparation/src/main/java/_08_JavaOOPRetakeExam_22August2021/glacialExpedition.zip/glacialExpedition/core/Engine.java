package _08_JavaOOPRetakeExam_22August2021.glacialExpedition.core;

public interface Engine extends Runnable {
}
