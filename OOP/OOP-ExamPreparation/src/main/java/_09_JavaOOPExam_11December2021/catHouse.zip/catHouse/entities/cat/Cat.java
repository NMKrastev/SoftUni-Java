package _09_JavaOOPExam_11December2021.catHouse.entities.cat;

public interface Cat {
    String getName();

    void setName(String name);

    int getKilograms();

    double getPrice();

    void eating();
}
