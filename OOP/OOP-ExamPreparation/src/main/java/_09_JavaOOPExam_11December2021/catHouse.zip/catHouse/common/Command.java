package _09_JavaOOPExam_11December2021.catHouse.common;

public enum Command {
    AddHouse,
    BuyToy,
    ToyForHouse,
    AddCat,
    FeedingCat,
    SumOfAll,
    Statistics,
    End
}
