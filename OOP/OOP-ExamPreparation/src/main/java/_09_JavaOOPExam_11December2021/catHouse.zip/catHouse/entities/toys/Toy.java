package _09_JavaOOPExam_11December2021.catHouse.entities.toys;

public interface Toy {
    int getSoftness();

    double getPrice();
}
