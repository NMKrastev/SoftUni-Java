package _09_JavaOOPExam_11December2021.catHouse.core;

public interface Engine extends Runnable {
}

