package _13_JavaOOPExam_14August2022.football.entities.supplement;

public interface Supplement {
    int getEnergy();

    double getPrice();
}
