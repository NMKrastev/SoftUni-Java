package _13_JavaOOPExam_14August2022.football.core;

public interface Engine extends Runnable {
}
