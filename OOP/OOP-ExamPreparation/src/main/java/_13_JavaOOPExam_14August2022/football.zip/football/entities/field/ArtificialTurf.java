package _13_JavaOOPExam_14August2022.football.entities.field;

public class ArtificialTurf extends BaseField {

    private static final int CAPACITY = 150;

    public ArtificialTurf(String name) {
        super(name, CAPACITY);
    }
}
