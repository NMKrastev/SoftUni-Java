package _13_JavaOOPExam_14August2022.football.common;
public enum Command {
    AddField,
    DeliverySupplement,
    SupplementForField,
    AddPlayer,
    DragPlayer,
    CalculateStrength,
    GetStatistics,
    Exit
}

