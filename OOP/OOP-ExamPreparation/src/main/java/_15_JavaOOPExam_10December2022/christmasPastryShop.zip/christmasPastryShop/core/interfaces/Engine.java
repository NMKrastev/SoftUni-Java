package _15_JavaOOPExam_10December2022.christmasPastryShop.core.interfaces;

public interface Engine {
    void run();
}
