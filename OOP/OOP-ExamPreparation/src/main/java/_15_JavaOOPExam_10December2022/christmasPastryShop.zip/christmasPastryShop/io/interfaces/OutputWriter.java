package _15_JavaOOPExam_10December2022.christmasPastryShop.io.interfaces;

public interface OutputWriter {
    void writeLine(String text);
}
