package _15_JavaOOPExam_10December2022.christmasPastryShop.common.enums;

public enum CocktailType {
    MulledWine,
    Hibernation
}
