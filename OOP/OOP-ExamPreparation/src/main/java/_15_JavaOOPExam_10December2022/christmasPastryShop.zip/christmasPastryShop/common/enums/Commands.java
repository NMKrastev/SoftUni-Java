package _15_JavaOOPExam_10December2022.christmasPastryShop.common.enums;

public enum Commands {
    AddDelicacy,
    AddCocktail,
    AddBooth,
    ReserveBooth,
    OrderDelicacy,
    OrderCocktail,
    LeaveBooth,
    GetIncome,
    END
}
