package _15_JavaOOPExam_10December2022.christmasPastryShop.io.interfaces;

import java.io.IOException;

public interface InputReader {
    String readLine() throws IOException;
}
