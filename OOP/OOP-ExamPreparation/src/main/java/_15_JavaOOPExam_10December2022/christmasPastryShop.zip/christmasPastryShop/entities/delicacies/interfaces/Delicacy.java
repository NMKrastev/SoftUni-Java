package _15_JavaOOPExam_10December2022.christmasPastryShop.entities.delicacies.interfaces;

public interface Delicacy {
    String getName();

    double getPortion();

    double getPrice();
}
