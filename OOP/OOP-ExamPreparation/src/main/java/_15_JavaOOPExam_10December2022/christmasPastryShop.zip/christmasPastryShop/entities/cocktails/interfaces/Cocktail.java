package _15_JavaOOPExam_10December2022.christmasPastryShop.entities.cocktails.interfaces;

public interface Cocktail {
    String getName();

    int getSize();

    double getPrice();

    String getBrand();
}
