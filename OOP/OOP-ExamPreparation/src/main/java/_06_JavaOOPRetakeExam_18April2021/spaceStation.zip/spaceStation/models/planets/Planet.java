package _06_JavaOOPRetakeExam_18April2021.spaceStation.models.planets;

import java.util.Collection;

public interface Planet {
    Collection<String> getItems();

    String getName();
}
