package _06_JavaOOPRetakeExam_18April2021.spaceStation.core;

public interface Engine extends Runnable {
}
