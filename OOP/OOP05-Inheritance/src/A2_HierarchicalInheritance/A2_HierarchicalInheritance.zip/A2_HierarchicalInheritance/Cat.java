package A2_HierarchicalInheritance;

public class Cat extends Animal {

    public void meow() {
        System.out.println("meowing...");
    }
}
