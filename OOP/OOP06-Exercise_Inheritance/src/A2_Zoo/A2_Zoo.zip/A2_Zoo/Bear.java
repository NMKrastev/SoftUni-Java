package A2_Zoo;

public class Bear extends Mammal {

    public Bear(String name) {
        super(name);
    }
}
