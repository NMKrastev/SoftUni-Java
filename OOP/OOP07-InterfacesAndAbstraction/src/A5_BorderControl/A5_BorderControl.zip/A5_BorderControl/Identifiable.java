package A5_BorderControl;

public interface Identifiable {

    String getId();
}
