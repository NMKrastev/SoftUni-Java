package A6_Ferrari;

public interface Car {

    String brakes();

    String gas();
}
