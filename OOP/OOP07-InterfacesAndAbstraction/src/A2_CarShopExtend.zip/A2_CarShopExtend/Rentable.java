package A2_CarShopExtend;

public interface Rentable {

    Integer getMinRentDay();

    Double getPricePerDay();
}
