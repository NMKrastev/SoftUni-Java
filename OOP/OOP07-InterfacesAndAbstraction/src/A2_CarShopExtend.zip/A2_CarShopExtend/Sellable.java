package A2_CarShopExtend;

public interface Sellable {

    Double getPrice();
}
