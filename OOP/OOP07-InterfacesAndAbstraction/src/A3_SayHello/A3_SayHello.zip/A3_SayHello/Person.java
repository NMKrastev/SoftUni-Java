package A3_SayHello;

public interface Person {

    String getName();

    String sayHello();
}
