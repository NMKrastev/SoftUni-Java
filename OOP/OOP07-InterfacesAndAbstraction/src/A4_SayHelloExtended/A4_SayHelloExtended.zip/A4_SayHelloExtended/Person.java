package A4_SayHelloExtended;

public interface Person {

    String getName();

    String sayHello();

}
